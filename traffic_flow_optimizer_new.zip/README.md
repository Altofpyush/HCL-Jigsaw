# Traffic Flow Optimizer

A deterministic Streamlit simulation comparing fixed-timer and traffic-responsive signal rules.

## Files
- `streamlit_app.py` — application entry point
- `requirements.txt` — Python dependencies

## Run locally
```bash
pip install -r requirements.txt
streamlit run streamlit_app.py
```

## Deploy
Push these files to a GitHub repository, then deploy `streamlit_app.py` using Streamlit Community Cloud.

## Important scope note
Ek Murti Chowk is a roundabout. This is a simplified four-approach signal simulation inspired by the school vicinity, not an exact model of the roundabout or its current traffic controls. Default arrival values are illustrative estimates, not field measurements.

For automatic Excel import, provide a worksheet with columns named `Approach` and `Arrivals`, with rows `North`, `East`, `South`, and `West`. Otherwise, enter arrivals manually in the sidebar.
