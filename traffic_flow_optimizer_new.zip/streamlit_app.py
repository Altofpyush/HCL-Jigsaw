import math
from collections import deque

import pandas as pd
import streamlit as st


st.set_page_config(
    page_title="Traffic Flow Optimizer",
    page_icon="🚦",
    layout="wide",
)

APPROACHES = ["North", "East", "South", "West"]
DEFAULT_ARRIVALS = {"North": 120, "East": 90, "South": 75, "West": 60}


def distribute_arrivals(total, duration):
    """Return a deterministic, evenly distributed arrival count for each second."""
    counts = [0] * duration
    if total <= 0:
        return counts
    for vehicle in range(total):
        second = min(duration - 1, int(vehicle * duration / total))
        counts[second] += 1
    return counts


def simulate(
    arrivals_by_approach,
    duration,
    clearance_seconds,
    fixed_green_seconds,
    smart_max_green_seconds,
    discharge_rate,
    mode,
):
    queues = {name: deque() for name in APPROACHES}
    arrival_events = {
        name: distribute_arrivals(arrivals_by_approach[name], duration)
        for name in APPROACHES
    }
    served_waits = []
    queue_history = []
    total_processed = 0
    service_credit = 0.0
    phase_index = 0
    phase_elapsed = 0
    clearance_elapsed = 0
    in_clearance = False
    smart_min_green = min(8, smart_max_green_seconds)

    for second in range(duration):
        # The same deterministic arrivals are used by both models.
        for name in APPROACHES:
            for _ in range(arrival_events[name][second]):
                queues[name].append(second)

        if in_clearance:
            clearance_elapsed += 1
            if clearance_elapsed >= clearance_seconds:
                in_clearance = False
                clearance_elapsed = 0
                phase_elapsed = 0
                if mode == "smart":
                    # At each new phase, serve the approach with the largest queue.
                    phase_index = max(
                        range(len(APPROACHES)),
                        key=lambda i: (len(queues[APPROACHES[i]]), -i),
                    )
                else:
                    phase_index = (phase_index + 1) % len(APPROACHES)
        else:
            active = APPROACHES[phase_index]
            service_credit += discharge_rate
            vehicles_to_serve = int(service_credit)
            service_credit -= vehicles_to_serve

            for _ in range(vehicles_to_serve):
                if queues[active]:
                    arrival_second = queues[active].popleft()
                    served_waits.append(second - arrival_second)
                    total_processed += 1

            phase_elapsed += 1
            if mode == "fixed":
                phase_limit = fixed_green_seconds
            else:
                phase_limit = smart_max_green_seconds

            should_switch = phase_elapsed >= phase_limit
            if mode == "smart" and phase_elapsed >= smart_min_green:
                # Switch early when another approach has a longer queue.
                other_max = max(
                    len(queues[name])
                    for name in APPROACHES
                    if name != active
                )
                should_switch = should_switch or other_max > len(queues[active])

            if should_switch:
                in_clearance = True
                clearance_elapsed = 0

        queue_history.append(
            {
                "second": second + 1,
                **{name: len(queues[name]) for name in APPROACHES},
                "total_queue": sum(len(queues[name]) for name in APPROACHES),
            }
        )

    total_arrivals = sum(arrivals_by_approach.values())
    average_wait = (
        sum(served_waits) / len(served_waits) if served_waits else 0.0
    )
    max_approach_queue = max(
        (max(row[name] for row in queue_history) for name in APPROACHES),
        default=0,
    )
    throughput = total_processed / (duration / 3600)

    return {
        "Vehicles arrived": total_arrivals,
        "Vehicles processed": total_processed,
        "Average wait (s)": round(average_wait, 1),
        "Maximum approach queue": max_approach_queue,
        "Throughput (vehicles/hour)": round(throughput, 1),
        "history": pd.DataFrame(queue_history),
    }


def read_workbook(uploaded_file):
    """Read an uploaded workbook and look for a simple Approach/Arrivals table."""
    workbook = pd.ExcelFile(uploaded_file)
    candidates = []
    for sheet in workbook.sheet_names:
        frame = pd.read_excel(workbook, sheet_name=sheet)
        if frame.empty:
            continue
        normalized = {str(column).strip().lower(): column for column in frame.columns}
        approach_col = next(
            (normalized[key] for key in normalized if key in
             ["approach", "direction", "road", "lane"]),
            None,
        )
        arrivals_col = next(
            (normalized[key] for key in normalized if key in
             ["arrivals", "vehicles", "vehicle arrivals", "vehicle_count", "count"]),
            None,
        )
        if approach_col is not None and arrivals_col is not None:
            for _, row in frame.iterrows():
                approach = str(row[approach_col]).strip().title()
                if approach in APPROACHES and pd.notna(row[arrivals_col]):
                    candidates.append((approach, max(0, int(float(row[arrivals_col])))))
            if candidates:
                return dict(candidates)
    raise ValueError(
        "I couldn't find a table with columns such as Approach and Arrivals. "
        "Use the controls below, or arrange a worksheet with those two columns."
    )


st.title("🚦 Traffic Flow Optimizer")
st.caption(
    "Deterministic educational simulation | Ek Murti Chowk vicinity, "
    "near Pacific World School, Greater Noida West"
)

st.warning(
    "Scope: Ek Murti Chowk is a roundabout. This is a simplified four-approach "
    "signal simulation inspired by the school vicinity, not an exact model of "
    "the roundabout or its current traffic controls. All default inputs are "
    "illustrative estimates, not field measurements."
)

with st.sidebar:
    st.header("Simulation controls")
    duration_minutes = st.slider("Simulation duration (minutes)", 5, 60, 15)
    clearance_seconds = st.slider("Clearance per phase (seconds)", 0, 10, 4)
    fixed_green_seconds = st.slider("Fixed green (seconds)", 5, 60, 20)
    smart_max_green_seconds = st.slider("Smart maximum green (seconds)", 8, 90, 28)
    discharge_rate = st.slider(
        "Discharge rate (vehicles/second)", 0.1, 2.0, 0.5, 0.1
    )

    st.subheader("Arrivals during the full simulation")
    arrivals = {}
    for approach in APPROACHES:
        arrivals[approach] = st.number_input(
            f"{approach} approach — vehicles",
            min_value=0,
            max_value=5000,
            value=DEFAULT_ARRIVALS[approach],
            step=5,
        )

    st.divider()
    st.subheader("Optional workbook")
    uploaded = st.file_uploader(
        "Upload an Excel workbook (.xlsx)",
        type=["xlsx"],
        help=(
            "For automatic import, include a worksheet with columns named "
            "'Approach' and 'Arrivals', and rows North, East, South and West."
        ),
    )
    if uploaded is not None:
        try:
            imported = read_workbook(uploaded)
            for approach, value in imported.items():
                arrivals[approach] = value
            st.success("Recognised arrival data imported from the workbook.")
        except Exception as exc:
            st.error(str(exc))

    run_clicked = st.button("Run / recalculate simulation", type="primary", use_container_width=True)

duration = duration_minutes * 60
arrivals = {key: int(value) for key, value in arrivals.items()}

# Recalculate on every app rerun so the displayed results always reflect controls.
fixed = simulate(
    arrivals, duration, clearance_seconds, fixed_green_seconds,
    smart_max_green_seconds, discharge_rate, "fixed"
)
smart = simulate(
    arrivals, duration, clearance_seconds, fixed_green_seconds,
    smart_max_green_seconds, discharge_rate, "smart"
)

st.subheader("Model comparison")
metrics = [
    ("Vehicles processed", fixed["Vehicles processed"], smart["Vehicles processed"], "higher"),
    ("Average wait (s)", fixed["Average wait (s)"], smart["Average wait (s)"], "lower"),
    ("Maximum approach queue", fixed["Maximum approach queue"], smart["Maximum approach queue"], "lower"),
    ("Throughput (vehicles/hour)", fixed["Throughput (vehicles/hour)"], smart["Throughput (vehicles/hour)"], "higher"),
]
cols = st.columns(4)
for col, (label, fixed_value, smart_value, preferred) in zip(cols, metrics):
    delta = smart_value - fixed_value
    if preferred == "lower":
        delta_text = f"{abs(delta):g} lower" if delta < 0 else f"{delta:g} higher"
    else:
        delta_text = f"{delta:g} higher" if delta > 0 else f"{abs(delta):g} lower"
    col.metric(label, smart_value, delta_text)
    col.caption(f"Fixed-timer baseline: {fixed_value}")

st.subheader("Intersection playback snapshot")
play_second = st.slider(
    "Choose a simulated second to inspect",
    min_value=1,
    max_value=duration,
    value=min(1, duration),
)
history = smart["history"]
snapshot = history.iloc[play_second - 1]
intersection_cols = st.columns(4)
for col, approach in zip(intersection_cols, APPROACHES):
    col.metric(f"{approach} queue", int(snapshot[approach]), "vehicles")

st.caption(
    f"Smart model snapshot at second {play_second} of {duration}. "
    "Queue values are whole vehicles."
)

st.subheader("Queue through the run")
chart_data = smart["history"].set_index("second")[APPROACHES]
st.line_chart(chart_data, height=300)

st.subheader("Fixed-timer vs smart model")
comparison = pd.DataFrame(
    {
        "Fixed-timer": [
            fixed["Vehicles processed"],
            fixed["Average wait (s)"],
            fixed["Maximum approach queue"],
            fixed["Throughput (vehicles/hour)"],
        ],
        "Smart traffic-responsive": [
            smart["Vehicles processed"],
            smart["Average wait (s)"],
            smart["Maximum approach queue"],
            smart["Throughput (vehicles/hour)"],
        ],
    },
    index=[
        "Vehicles processed",
        "Average wait (seconds)",
        "Maximum approach queue",
        "Throughput (vehicles/hour)",
    ],
)
st.bar_chart(comparison)

st.subheader("Input data used")
input_table = pd.DataFrame(
    [{"Approach": name, "Arrivals in simulation": arrivals[name]} for name in APPROACHES]
)
st.dataframe(input_table, hide_index=True, use_container_width=True)

st.subheader("Methodology and assumptions")
st.markdown(
    """
- Both models receive the **same deterministic arrival schedule**.
- Arrivals are distributed evenly across the selected simulation duration.
- The fixed-timer model gives each approach the same green duration.
- The smart model selects the approach with the largest queue at phase changes
  and may switch earlier when another queue becomes longer.
- Vehicles are counted as whole units; fractional service capacity is carried
  forward internally between seconds.
- Average waiting time is calculated for vehicles that were processed during
  the simulation. Vehicles still queued at the end are not included in that
  average, so interpret the metric alongside the remaining queues.
- This is a simplified educational model. It does not represent measured
  traffic, pedestrian crossings, lane geometry, turning movements, or the
  actual operating rules of Ek Murti Chowk.
    """
)

st.subheader("Export results")
summary = pd.DataFrame(
    [
        {"Model": "Fixed-timer", **{k: v for k, v in fixed.items() if k != "history"}},
        {"Model": "Smart traffic-responsive", **{k: v for k, v in smart.items() if k != "history"}},
    ]
)
st.download_button(
    "Download comparison results (CSV)",
    data=summary.to_csv(index=False).encode("utf-8"),
    file_name="traffic_flow_comparison.csv",
    mime="text/csv",
)

st.divider()
st.caption(
    "HCL Jigsaw / Round 2 | team_965_0045 | 4 members | "
    "SIMULATED / ESTIMATED — NOT FIELD MEASUREMENTS"
)
